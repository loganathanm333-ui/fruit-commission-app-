package com.logan.fruitcommission

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import java.text.SimpleDateFormat
import java.util.*

data class Bill(
    val no: Int,
    val customer: String,
    val fruit: String,
    val qty: Double,
    val rate: Double,
    val commission: Double,
    val expense: Double,
    val date: String
) {
    val gross get() = qty * rate
    val net get() = gross - commission - expense
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FruitCommissionApp() }
    }
}

@Composable
fun FruitCommissionApp() {
    var screen by remember { mutableStateOf("home") }
    var billNo by remember { mutableIntStateOf(1) }
    val bills = remember { mutableStateListOf<Bill>() }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF2E7D32),
            secondary = Color(0xFFFF8F00)
        )
    ) {
        when (screen) {
            "home" -> HomeScreen(bills, onNewBill = { screen = "bill" },
                onCustomers = { screen = "customers" }, onSuppliers = { screen = "suppliers" },
                onReports = { screen = "reports" }, onCollection = { screen = "collection" })
            "bill" -> NewBillScreen(
                no = billNo,
                onBack = { screen = "home" },
                onSave = { customer, fruit, qty, rate, commission, expense ->
                    bills.add(Bill(billNo++, customer, fruit, qty, rate, commission, expense, today()))
                    screen = "home"
                }
            )
            "customers" -> SimpleListScreen("👥 Customers", listOf("Add customers from New Bill", "Customer outstanding will appear here"), { screen = "home" })
            "suppliers" -> SimpleListScreen("🚚 Suppliers", listOf("Supplier / Farmer records", "Goods received & payable"), { screen = "home" })
            "collection" -> SimpleListScreen("💰 Collection", listOf("Cash", "UPI", "Bank", "Partial payment"), { screen = "home" })
            "reports" -> ReportScreen(bills, { screen = "home" })
        }
    }
}

fun today(): String = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
fun money(v: Double) = "₹%,.2f".format(Locale.US, v)

@Composable
fun HomeScreen(
    bills: List<Bill>, onNewBill: () -> Unit, onCustomers: () -> Unit,
    onSuppliers: () -> Unit, onReports: () -> Unit, onCollection: () -> Unit
) {
    val sales = bills.sumOf { it.gross }
    val commission = bills.sumOf { it.commission }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("🍎 LOGAN FRUIT COMMISSION", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Today: ${today()}", color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Today Sales", money(sales), Modifier.weight(1f))
            StatCard("Commission", money(commission), Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Bills", bills.size.toString(), Modifier.weight(1f))
            StatCard("Expenses", money(bills.sumOf { it.expense }), Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Button(onClick = onNewBill, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("➕ NEW BILL") }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onCollection, Modifier.weight(1f)) { Text("💰 Collection") }
            OutlinedButton(onClick = onCustomers, Modifier.weight(1f)) { Text("👥 Customers") }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onSuppliers, Modifier.weight(1f)) { Text("🚚 Suppliers") }
            OutlinedButton(onClick = onReports, Modifier.weight(1f)) { Text("📊 Reports") }
        }
        Spacer(Modifier.height(16.dp))
        Text("Recent Bills", fontWeight = FontWeight.Bold)
        LazyColumn {
            items(bills.takeLast(5).reversed()) { b ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("#${b.no} • ${b.customer}", fontWeight = FontWeight.Bold)
                        Text("${b.fruit} • ${b.qty} × ${money(b.rate)} = ${money(b.gross)}")
                        Text("Commission ${money(b.commission)} • Net ${money(b.net)}")
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Color.Gray)
            Text(value, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun NewBillScreen(
    no: Int, onBack: () -> Unit,
    onSave: (String, String, Double, Double, Double, Double) -> Unit
) {
    var customer by remember { mutableStateOf("") }
    var fruit by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var commission by remember { mutableStateOf("") }
    var expense by remember { mutableStateOf("0") }

    val gross = (qty.toDoubleOrNull() ?: 0.0) * (rate.toDoubleOrNull() ?: 0.0)
    val net = gross - (commission.toDoubleOrNull() ?: 0.0) - (expense.toDoubleOrNull() ?: 0.0)

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("🧾 New Bill", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("#$no", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Field("Buyer / Customer", customer) { customer = it }
        Field("Fruit", fruit) { fruit = it }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Quantity", qty, Modifier.weight(1f)) { qty = it }
            Field("Rate", rate, Modifier.weight(1f)) { rate = it }
        }
        Field("Commission Amount", commission) { commission = it }
        Field("Other Expense", expense) { expense = it }
        Spacer(Modifier.height(12.dp))
        Text("Gross Total: ${money(gross)}", fontWeight = FontWeight.Bold)
        Text("Net Amount: ${money(net)}", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = { onSave(customer, fruit, qty.toDoubleOrNull() ?: 0.0, rate.toDoubleOrNull() ?: 0.0,
                commission.toDoubleOrNull() ?: 0.0, expense.toDoubleOrNull() ?: 0.0) },
            enabled = customer.isNotBlank() && fruit.isNotBlank() && (qty.toDoubleOrNull() ?: 0.0) > 0,
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("SAVE BILL") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onBack, Modifier.fillMaxWidth()) { Text("BACK") }
    }
}

@Composable
fun Field(label: String, value: String, modifier: Modifier = Modifier.fillMaxWidth(), onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        modifier = modifier.padding(vertical = 4.dp), singleLine = true
    )
}

@Composable
fun SimpleListScreen(title: String, rows: List<String>, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        rows.forEach { Text("• $it", Modifier.padding(8.dp)) }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onBack, Modifier.fillMaxWidth()) { Text("HOME") }
    }
}

@Composable
fun ReportScreen(bills: List<Bill>, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("📊 Reports", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Total Sales: ${money(bills.sumOf { it.gross })}")
        Text("Total Commission: ${money(bills.sumOf { it.commission })}")
        Text("Total Expenses: ${money(bills.sumOf { it.expense })}")
        Text("Net: ${money(bills.sumOf { it.net })}")
        Text("Bills: ${bills.size}")
        Spacer(Modifier.height(16.dp))
        Button(onClick = onBack, Modifier.fillMaxWidth()) { Text("HOME") }
    }
}
