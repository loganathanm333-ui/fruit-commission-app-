# Fruit Commission Android App
Version 1.0 starter build.

Features:
- Dashboard
- New bill with multiple financial fields
- Customer/Supplier/Collection placeholders
- Reports
- Offline in-memory billing for the current app session

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).

This is a working starter project. Persistent database, PDF/WhatsApp bill sharing,
UPI integration, supplier ledger, and backup/sync can be added in the next version.
