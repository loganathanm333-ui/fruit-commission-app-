# Phone-only APK build

இந்த project-ல் GitHub Actions workflow சேர்க்கப்பட்டுள்ளது.

Phone மட்டும் வைத்து:
1. GitHub-ல் புதிய repository உருவாக்கவும்.
2. இந்த ZIP-ஐ upload/unzip செய்து files-ஐ repository-க்கு upload செய்யவும்.
3. GitHub → Actions → "Build APK" → Run workflow.
4. Build முடிந்ததும் workflow Artifacts பகுதியில் `fruit-commission-debug-apk` download செய்யவும்.
5. APK-ஐ phone-ல் install செய்யவும்.

குறிப்பு: இது debug APK. Production/public releaseக்கு signing key தேவை.

App logic:
- Commission default 10%
- Transport default Rs 22
- Quantity × Rate = Subtotal
- Previous Balance + Subtotal = Current Balance
- Invoice number auto-increments
