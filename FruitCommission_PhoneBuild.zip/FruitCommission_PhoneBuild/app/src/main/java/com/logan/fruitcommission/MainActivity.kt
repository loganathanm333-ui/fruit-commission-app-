package com.logan.fruitcommission

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

data class Bill(
    val no:Int, val customer:String, val phone:String, val fruit:String,
    val qty:Double, val unit:String, val rate:Double, val transport:Double,
    val commission:Double, val previous:Double, val date:String
) {
    val subtotal get() = qty * rate
    val current get() = previous + subtotal
    val commission10 get() = subtotal * commission / 100.0
}

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var page by remember { mutableStateOf("home") }
    var nextNo by remember { mutableIntStateOf(12345) }
    val bills = remember { mutableStateListOf<Bill>() }

    MaterialTheme(colorScheme = lightColorScheme(primary=Color(0xFF2E7D32))) {
        when(page) {
            "home" -> Home(bills, {page="bill"}, {page="customers"}, {page="reports"})
            "bill" -> BillPage(nextNo, {page="home"}) { c,p,f,q,u,r,t,comm,prev ->
                bills.add(Bill(nextNo++,c,p,f,q,u,r,t,comm,prev,today()))
                page="home"
            }
            "customers" -> ListPage("👥 Customers", "Customer balances and bill history", {page="home"})
            else -> Reports(bills,{page="home"})
        }
    }
}

fun today() = SimpleDateFormat("dd MMM, yyyy", Locale.getDefault()).format(Date())
fun rs(x:Double) = "Rs %.2f".format(Locale.US,x)

@Composable
fun Home(bills:List<Bill>, new:()->Unit, customers:()->Unit, reports:()->Unit) {
    val sales=bills.sumOf{it.subtotal}
    val comm=bills.sumOf{it.commission10}
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("🍎 Fruit Commission", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Text("Today: ${today()}", color=Color.Gray)
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Card(Modifier.weight(1f)){Column(Modifier.padding(12.dp)){Text("Sales");Text(rs(sales),fontWeight=FontWeight.Bold)}}
            Card(Modifier.weight(1f)){Column(Modifier.padding(12.dp)){Text("10% Commission");Text(rs(comm),fontWeight=FontWeight.Bold)}}
        }
        Spacer(Modifier.height(12.dp))
        Button(new, Modifier.fillMaxWidth().height(54.dp)){Text("➕ NEW BILL")}
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(customers,Modifier.weight(1f)){Text("👥 Customers")}
            OutlinedButton(reports,Modifier.weight(1f)){Text("📊 Reports")}
        }
        Spacer(Modifier.height(14.dp))
        Text("Recent Bills",fontWeight=FontWeight.Bold)
        LazyColumn { items(bills.takeLast(10).reversed()) { b ->
            Card(Modifier.fillMaxWidth().padding(vertical=3.dp)){
                Column(Modifier.padding(10.dp)){
                    Text("#${b.no}  ${b.customer}",fontWeight=FontWeight.Bold)
                    Text("${b.fruit} • ${b.qty} ${b.unit} × ${rs(b.rate)} = ${rs(b.subtotal)}")
                    Text("Balance after bill: ${rs(b.current)}")
                }
            }
        }}
    }
}

@Composable
fun BillPage(no:Int, back:()->Unit, save:(String,String,String,Double,String,Double,Double,Double,Double)->Unit) {
    var c by remember{mutableStateOf("")}; var p by remember{mutableStateOf("")}
    var f by remember{mutableStateOf("")}; var q by remember{mutableStateOf("")}
    var u by remember{mutableStateOf("Box")}; var r by remember{mutableStateOf("")}
    var tr by remember{mutableStateOf("22")}; var comm by remember{mutableStateOf("10")}
    var prev by remember{mutableStateOf("0")}
    val gross=(q.toDoubleOrNull()?:0.0)*(r.toDoubleOrNull()?:0.0)
    val bal=(prev.toDoubleOrNull()?:0.0)+gross
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
            Text("Sales Invoice",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
            Text("#$no",fontWeight=FontWeight.Bold)
        }
        Text(today(),color=Color.Gray)
        Spacer(Modifier.height(8.dp))
        F("Bill To / Customer",c){c=it}; F("Mobile",p){p=it}; F("Fruit",f){f=it}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
            F("Quantity",q,Modifier.weight(1f)){q=it}; F("Unit",u,Modifier.weight(1f)){u=it}
        }
        F("Price / Unit",r){r=it}
        F("Transport",tr){tr=it}; F("Commission %",comm){comm=it}; F("Previous Balance",prev){prev=it}
        Spacer(Modifier.height(8.dp))
        Text("Subtotal: ${rs(gross)}",fontWeight=FontWeight.Bold)
        Text("Commission: ${rs(gross*(comm.toDoubleOrNull()?:10.0)/100)}")
        Text("Current Balance: ${rs(bal)}",fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Button({save(c,p,f,q.toDoubleOrNull()?:0.0,u,r.toDoubleOrNull()?:0.0,tr.toDoubleOrNull()?:0.0,comm.toDoubleOrNull()?:10.0,prev.toDoubleOrNull()?:0.0)},
            enabled=c.isNotBlank()&&f.isNotBlank()&&(q.toDoubleOrNull()?:0.0)>0,
            Modifier.fillMaxWidth().height(54.dp)){Text("SAVE BILL")}
        OutlinedButton(back,Modifier.fillMaxWidth()){Text("BACK")}
    }
}

@Composable
fun F(label:String,value:String,modifier:Modifier=Modifier.fillMaxWidth(),on: (String)->Unit)=
    OutlinedTextField(value,onValueChange=on,label={Text(label)},modifier=modifier.padding(vertical=3.dp),singleLine=true)

@Composable
fun ListPage(title:String,sub:String,back:()->Unit)=Column(Modifier.fillMaxSize().padding(16.dp)){
    Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
    Spacer(Modifier.height(8.dp)); Text(sub)
    Spacer(Modifier.height(20.dp)); Button(back,Modifier.fillMaxWidth()){Text("HOME")}
}

@Composable
fun Reports(bills:List<Bill>,back:()->Unit)=Column(Modifier.fillMaxSize().padding(16.dp)){
    Text("📊 Reports",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    Text("Total Bills: ${bills.size}")
    Text("Total Sales: ${rs(bills.sumOf{it.subtotal})}")
    Text("Total Commission: ${rs(bills.sumOf{it.commission10})}")
    Text("Transport: ${rs(bills.sumOf{it.transport})}")
    Spacer(Modifier.height(16.dp)); Button(back,Modifier.fillMaxWidth()){Text("HOME")}
}
